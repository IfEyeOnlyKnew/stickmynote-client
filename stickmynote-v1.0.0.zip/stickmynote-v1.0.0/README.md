# Stick My Note

A collaborative note-taking and task management application designed for on-premises enterprise deployment with Active Directory integration.

## Features

- **Personal Notes (Sticks)** - Create, organize, and share sticky notes
- **Collaborative Pads** - Team workspaces with shared content
- **Calendar Tasks (Calsticks)** - Task management with multiple views (Calendar, Kanban, Agenda, Timeline)
- **Social Collaboration** - Community notes, reactions, and discussions
- **Rich Text Editing** - Tiptap-based editor with real-time collaboration (Yjs)
- **Active Directory Integration** - LDAP/LDAPS authentication
- **AI-Powered Features** - Note summarization, tag generation (optional)
- **Multi-tenant Support** - Organizations with role-based access

## Tech Stack

- **Frontend**: Next.js 14, React 19, TypeScript, Tailwind CSS
- **UI Components**: Radix UI, Shadcn/ui
- **Database**: PostgreSQL
- **Authentication**: LDAP/Active Directory, JWT
- **Real-time**: Yjs for collaborative editing
- **Caching**: Redis (optional)

## Quick Start

### Prerequisites

- Node.js 18.x or 20.x LTS
- pnpm (recommended) or npm
- PostgreSQL 14.x or 15.x
- Active Directory with LDAPS enabled (for AD auth)

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd stickmynote-client
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Configure environment**
   ```bash
   cp .env.example .env.local
   # Edit .env.local with your settings
   ```

4. **Run database migrations**
   ```bash
   pnpm run migrate
   ```

5. **Build the application**
   ```bash
   pnpm run build
   ```

6. **Start the server**
   ```bash
   pnpm run start
   ```

The application will be available at `http://localhost:80` (or the configured PORT).

## Configuration

See [.env.example](.env.example) for all configuration options.

### Required Settings

| Variable | Description |
|----------|-------------|
| `POSTGRES_HOST` | PostgreSQL server hostname |
| `POSTGRES_PASSWORD` | Database password |
| `JWT_SECRET` | 64-byte hex string for JWT signing |
| `CSRF_SECRET` | 64-byte hex string for CSRF protection |
| `LDAP_URL` | LDAP server URL (e.g., `ldaps://dc.domain.com:636`) |
| `LDAP_BIND_PASSWORD` | LDAP service account password |

### Generate Secrets

```bash
# Generate a secure secret
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

## Windows Service Deployment

For production Windows deployment using NSSM:

1. Download [NSSM](https://nssm.cc/)
2. Install as a service:
   ```powershell
   nssm install StickyMyNote "C:\path\to\node.exe" "server.js"
   nssm set StickyMyNote AppDirectory "C:\path\to\stickmynote-client"
   nssm start StickyMyNote
   ```

See [docs/INFRASTRUCTURE_REQUIREMENTS.md](docs/INFRASTRUCTURE_REQUIREMENTS.md) for detailed infrastructure setup.

## SSL/HTTPS

### Option 1: Self-signed certificates (testing)

```bash
mkdir certs
openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
  -keyout certs/server.key -out certs/server.crt \
  -subj "/CN=localhost"
```

### Option 2: Cloudflare (recommended for production)

Configure Cloudflare with Full SSL mode. The application will run on HTTPS (port 443) with self-signed certs, and Cloudflare handles public SSL termination.

## Documentation

- [Infrastructure Requirements](docs/INFRASTRUCTURE_REQUIREMENTS.md) - Server and network setup
- [Packaging & Distribution](docs/PACKAGING_AND_DISTRIBUTION.md) - Distribution guide
- [Architecture Diagrams](docs/ARCHITECTURE_DIAGRAMS.md) - Mermaid diagrams for developers

## Project Structure

```
├── app/                  # Next.js App Router pages and API routes
│   ├── api/             # API endpoints
│   ├── auth/            # Authentication pages
│   ├── dashboard/       # Main dashboard
│   ├── calsticks/       # Calendar/task views
│   └── social/          # Social features
├── components/          # React components
│   ├── ui/              # Base UI components (Shadcn)
│   ├── rich-text/       # Tiptap editors
│   ├── calsticks/       # Calendar components
│   └── social/          # Social components
├── lib/                 # Core libraries
│   ├── auth/            # Authentication logic
│   ├── database/        # PostgreSQL client
│   └── ai/              # AI service providers
├── hooks/               # Custom React hooks
├── contexts/            # React Context providers
├── migrations/          # Database migrations
└── docs/                # Documentation
```

## API Routes

The application uses a v2 API structure:

- `/api/v2/users/[userId]/*` - User resources
- `/api/v2/organizations/[orgId]/*` - Organization resources
- `/api/v2/pads/[padId]/*` - Pad (workspace) resources
- `/api/v2/social-sticks/*` - Social content
- `/api/auth/*` - Authentication endpoints

## Development

```bash
# Development server with hot reload
pnpm run dev

# Run tests
pnpm run test

# Lint code
pnpm run lint

# Type check
pnpm run type-check
```

## Scripts

| Script | Description |
|--------|-------------|
| `pnpm dev` | Start development server |
| `pnpm build` | Build for production |
| `pnpm start` | Start production server |
| `pnpm test` | Run tests |
| `pnpm lint` | Run ESLint |
| `pnpm migrate` | Run database migrations |

## Support

For issues and feature requests, contact your system administrator or refer to the documentation.

## License

Proprietary - All rights reserved.
