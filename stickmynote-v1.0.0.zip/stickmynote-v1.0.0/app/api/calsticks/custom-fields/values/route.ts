import { type NextRequest, NextResponse } from "next/server"
import { createDatabaseClient } from "@/lib/database/database-adapter"
import { getOrgContext } from "@/lib/auth/get-org-context"
import { getCachedAuthUser } from "@/lib/auth/cached-auth"

export async function GET(request: NextRequest) {
  try {
    const db = await createDatabaseClient()
    const authResult = await getCachedAuthUser()
    if (authResult.rateLimited) {
      return NextResponse.json({ error: "Rate limited" }, { status: 429, headers: { "Retry-After": "30" } })
    }
    if (!authResult.userId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    try {
      await getOrgContext()
    } catch (error) {
      console.error("[custom-fields/values GET] Org context error:", error)
      // No org context - continue without org filtering
    }

    const { searchParams } = new URL(request.url)
    const taskId = searchParams.get("taskId")

    if (!taskId) {
      return NextResponse.json({ error: "Missing taskId" }, { status: 400 })
    }

    const { data: values, error } = await db
      .from("custom_field_values")
      .select("*")
      .eq("task_id", taskId)

    if (error) {
      if (error.code === "PGRST204" || error.message?.includes("Could not find the table")) {
        return NextResponse.json({
          values: [],
          tableNotFound: true,
          message: "Custom fields table not created yet. Run scripts/add-calstick-custom-fields.sql",
        })
      }
      return NextResponse.json({ error: "Failed to fetch field values" }, { status: 500 })
    }

    // Fetch definitions separately
    const fieldIds = [...new Set((values || []).map((v: any) => v.field_id).filter(Boolean))]
    let definitionMap: Record<string, any> = {}
    if (fieldIds.length > 0) {
      const { data: definitions } = await db
        .from("custom_field_definitions")
        .select("*")
        .in("id", fieldIds)

      if (definitions) {
        definitionMap = Object.fromEntries(definitions.map((d: any) => [d.id, d]))
      }
    }

    // Attach definitions to values
    const valuesWithDefinitions = (values || []).map((value: any) => ({
      ...value,
      definition: definitionMap[value.field_id] || null,
    }))

    return NextResponse.json({ values: valuesWithDefinitions })
  } catch (error) {
    console.error("[custom-fields/values GET] Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const db = await createDatabaseClient()
    const authResult = await getCachedAuthUser()
    if (authResult.rateLimited) {
      return NextResponse.json({ error: "Rate limited" }, { status: 429, headers: { "Retry-After": "30" } })
    }
    if (!authResult.userId) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    try {
      await getOrgContext()
    } catch (error) {
      console.error("[custom-fields/values POST] Org context error:", error)
      // No org context - continue without it
    }

    const body = await request.json()
    const { taskId, fieldId, value, type } = body

    const valueData: any = {
      task_id: taskId,
      field_id: fieldId,
      value_text: null,
      value_number: null,
      value_date: null,
      value_boolean: null,
    }

    if (type === "number") {
      valueData.value_number = value
    } else if (type === "date") {
      valueData.value_date = value
    } else if (type === "boolean") {
      valueData.value_boolean = value
    } else {
      valueData.value_text = value
    }

    const { data, error } = await db
      .from("custom_field_values")
      .upsert(valueData, { onConflict: "task_id, field_id" })
      .select()
      .single()

    if (error) {
      if (error.code === "PGRST204" || error.message?.includes("Could not find the table")) {
        return NextResponse.json(
          {
            error: "Custom fields table not created yet",
            tableNotFound: true,
          },
          { status: 400 },
        )
      }
      return NextResponse.json({ error: "Failed to save field value" }, { status: 500 })
    }

    return NextResponse.json({ value: data })
  } catch (error) {
    console.error("[custom-fields/values POST] Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
